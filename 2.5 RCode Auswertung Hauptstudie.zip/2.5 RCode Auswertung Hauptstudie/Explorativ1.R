# ============================================================
# EXPLORATIV 1 – FAKTOR: SWITCHER VS. STABIL
# ============================================================

cat("\n==============================\n")
cat("EXPLORATIV: TRANSITIONEN & SWITCHER\n")
cat("==============================\n\n")

cat("---- Wechselrate & Richtungsverteilung (post_defined; ungewichtet) ----\n\n")
cat("Wechselrate gesamt:\n"); print(change_rate_total); cat("\n")
cat("Richtungsverteilung:\n"); print(change_direction_total); cat("\n")

cat("---- Transition-Raten nach Source×Veracity ----\n\n")
cat("Gewichtet (Pfadgewichte):\n"); print(desc_transitions_w); cat("\n")
cat("Ungewichtet (Häufigkeitsbasis):\n"); print(desc_transitions_nw); cat("\n")

cat("---- Switcher-Sample ----\n\n")
cat("n_items:\n"); print(nrow(dat_conf_switch)); cat("\n")
cat("n_persons:\n"); print(dplyr::n_distinct(dat_conf_switch$id)); cat("\n\n")

cat("---- Switcher: Confidence-Change (Item-Ebene) ----\n\n")
cat("Gewichtet (mean + w_disp + w_sd_df):\n"); print(switch_conf_total_w); cat("\n")
cat("Ungewichtet (mean/sd + median/iqr):\n"); print(switch_conf_total_nw); cat("\n")

cat("Nach Source – gewichtet:\n"); print(switch_conf_by_source_w); cat("\n")
cat("Nach Source – ungewichtet:\n"); print(switch_conf_by_source_nw); cat("\n")

cat("Nach Source×Stimulus-Veracity – gewichtet:\n"); print(switch_conf_by_cond_w); cat("\n")
cat("Nach Source×Stimulus-Veracity – ungewichtet:\n"); print(switch_conf_by_cond_nw); cat("\n")

cat("Wechselrichtung (Pre->Post Urteil) nach Source×Stimulus-Veracity (ungewichtet; mit Zellflag):\n")
print(switch_dir_by_cond_nw); cat("\n")

cat("---- Switcher: Confidence-Change (Person-Ebene; pro Person aggregiert) ----\n\n")
cat("Gesamt – ungewichtet:\n"); print(switch_person_total_nw); cat("\n")
cat("Gesamt – gewichtet:\n"); print(switch_person_total_w); cat("\n")
cat("Nach Source – ungewichtet:\n"); print(switch_person_by_source_nw); cat("\n")
cat("Nach Source – gewichtet:\n"); print(switch_person_by_source_w); cat("\n")

# ------------------------------------------------------------
# Gemeinsamer Datensatz: Switcher vs. Stabil
# ------------------------------------------------------------

conf_switch_stable <- item_profile %>%
  filter(
    post_defined,
    pre_choice %in% c("real", "fake"),
    post_choice %in% c("real", "fake"),
    !is.na(pre_conf), !is.na(post_conf),
    !is.na(source), !is.na(veracity), !is.na(text_id)
  ) %>%
  left_join(id_w, by = "id") %>%
  mutate(
    status = ifelse(pre_choice != post_choice, "Switcher", "Stabil"),
    status = factor(status, levels = c("Stabil", "Switcher")),
    source_f = factor(source, levels = c("OKI", "KI")),
    veracity_f = factor(veracity, levels = c("Real", "Fake")),
    conf_change = post_conf - pre_conf
  )

# ------------------------------------------------------------
# Switcher vs. Stabil – Gesamtvergleich
# ------------------------------------------------------------

conf_switch_stable_total_w <- conf_switch_stable %>%
  group_by(status) %>%
  summarise(
    n = n(),
    w_sum = sum(w, na.rm = TRUE),
    mean_pre_conf = weighted.mean(pre_conf, w, na.rm = TRUE),
    mean_post_conf = weighted.mean(post_conf, w, na.rm = TRUE),
    mean_conf_change = weighted.mean(conf_change, w, na.rm = TRUE),
    w_disp_pre = w_dispersion(pre_conf, w),
    w_disp_post = w_dispersion(post_conf, w),
    w_disp_change = w_dispersion(conf_change, w),
    w_sd_df_change = w_sd_df(conf_change, w),
    .groups = "drop"
  )

conf_switch_stable_total_nw <- conf_switch_stable %>%
  group_by(status) %>%
  summarise(
    n = n(),
    mean_pre_conf = mean(pre_conf, na.rm = TRUE),
    mean_post_conf = mean(post_conf, na.rm = TRUE),
    mean_conf_change = mean(conf_change, na.rm = TRUE),
    sd_pre_conf = sd(pre_conf, na.rm = TRUE),
    sd_post_conf = sd(post_conf, na.rm = TRUE),
    sd_conf_change = sd(conf_change, na.rm = TRUE),
    median_conf_change = median(conf_change, na.rm = TRUE),
    iqr_conf_change = IQR(conf_change, na.rm = TRUE),
    .groups = "drop"
  )

# ------------------------------------------------------------
# Switcher vs. Stabil – nach Source
# ------------------------------------------------------------

conf_switch_stable_by_source_w <- conf_switch_stable %>%
  group_by(source_f, status) %>%
  summarise(
    n = n(),
    n_flag_lt20 = flag_small_n_tbl(n, 20),
    w_sum = sum(w, na.rm = TRUE),
    mean_pre_conf = weighted.mean(pre_conf, w, na.rm = TRUE),
    mean_post_conf = weighted.mean(post_conf, w, na.rm = TRUE),
    mean_conf_change = weighted.mean(conf_change, w, na.rm = TRUE),
    w_disp_change = w_dispersion(conf_change, w),
    w_sd_df_change = w_sd_df(conf_change, w),
    .groups = "drop"
  )

conf_switch_stable_by_source_nw <- conf_switch_stable %>%
  group_by(source_f, status) %>%
  summarise(
    n = n(),
    n_flag_lt20 = flag_small_n_tbl(n, 20),
    mean_pre_conf = mean(pre_conf, na.rm = TRUE),
    mean_post_conf = mean(post_conf, na.rm = TRUE),
    mean_conf_change = mean(conf_change, na.rm = TRUE),
    sd_conf_change = sd(conf_change, na.rm = TRUE),
    median_conf_change = median(conf_change, na.rm = TRUE),
    iqr_conf_change = IQR(conf_change, na.rm = TRUE),
    .groups = "drop"
  )

# ------------------------------------------------------------
# Alte Vergleichstabellen beibehalten
# ------------------------------------------------------------

conf_change_by_switcher <- conf_switch_stable %>%
  filter(status == "Switcher") %>%
  summarise(
    n = n(),
    mean_pre_conf = mean(pre_conf, na.rm = TRUE),
    mean_post_conf = mean(post_conf, na.rm = TRUE),
    mean_conf_change = mean(conf_change, na.rm = TRUE),
    sd_pre_conf = sd(pre_conf, na.rm = TRUE),
    sd_post_conf = sd(post_conf, na.rm = TRUE),
    .groups = "drop"
  )

conf_change_stable <- conf_switch_stable %>%
  filter(status == "Stabil") %>%
  summarise(
    n = n(),
    mean_pre_conf = mean(pre_conf, na.rm = TRUE),
    mean_post_conf = mean(post_conf, na.rm = TRUE),
    mean_conf_change = mean(conf_change, na.rm = TRUE),
    sd_pre_conf = sd(pre_conf, na.rm = TRUE),
    sd_post_conf = sd(post_conf, na.rm = TRUE),
    .groups = "drop"
  )

combined_conf_change <- bind_rows(
  tibble(
    group = "Switcher",
    n = conf_change_by_switcher$n,
    mean_pre_conf = conf_change_by_switcher$mean_pre_conf,
    mean_post_conf = conf_change_by_switcher$mean_post_conf,
    mean_conf_change = conf_change_by_switcher$mean_conf_change,
    sd_pre_conf = conf_change_by_switcher$sd_pre_conf,
    sd_post_conf = conf_change_by_switcher$sd_post_conf
  ),
  tibble(
    group = "Stabile Urteile",
    n = conf_change_stable$n,
    mean_pre_conf = conf_change_stable$mean_pre_conf,
    mean_post_conf = conf_change_stable$mean_post_conf,
    mean_conf_change = conf_change_stable$mean_conf_change,
    sd_pre_conf = conf_change_stable$sd_pre_conf,
    sd_post_conf = conf_change_stable$sd_post_conf
  )
)

cat("---- Confidence im Pre- und Post-Urteil: Switcher vs. stabile Urteile ----\n\n")
print(conf_change_by_switcher); cat("\n")
print(conf_change_stable); cat("\n")
print(combined_conf_change); cat("\n")

cat("---- Switcher vs. Stabil: gewichteter Gesamtvergleich ----\n\n")
print(conf_switch_stable_total_w); cat("\n")

cat("---- Switcher vs. Stabil: ungewichteter Gesamtvergleich ----\n\n")
print(conf_switch_stable_total_nw); cat("\n")

cat("---- Switcher vs. Stabil nach Source – gewichtet ----\n\n")
print(conf_switch_stable_by_source_w); cat("\n")

cat("---- Switcher vs. Stabil nach Source – ungewichtet ----\n\n")
print(conf_switch_stable_by_source_nw); cat("\n")

cat("---- Switcher vs. Stabil nach Source×Veracity – gewichtet ----\n\n")
print(conf_switch_stable_by_cond_w); cat("\n")

cat("---- Switcher vs. Stabil nach Source×Veracity – ungewichtet ----\n\n")
print(conf_switch_stable_by_cond_nw); cat("\n")

m_conf_switch_w <- lm(
  conf_change_switch ~ source_f * veracity_f + switch_dir + factor(id) + factor(text_id),
  data = dat_conf_switch, weights = w
)

conf_switch_w_robust <- robust_test(m_conf_switch_w, dat_conf_switch$id)

cat("\n*************** Ergebnisse für Switcher-Confidence ***************\n")
print(conf_switch_w_robust)