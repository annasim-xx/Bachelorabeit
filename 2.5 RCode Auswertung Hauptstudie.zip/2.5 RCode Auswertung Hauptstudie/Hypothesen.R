# ============================================================
# HYPOTHESENTESTS (H1–H3) – FE + robuste SE (Cluster = id) + Pfad-Gewichte
# Neue Logik:
# - H1/H2: Haupttest ohne Interaktion
# - H1/H2: Interaktion Source × Veracity separat als Design-Check
# - H3: korrigiert mit Sum-Kontrasten für text_id_f
# - H1: OR + 95%-KI
# - H2/H3: β + 95%-KI
# ============================================================

# ------------------------------------------------------------
# 1) Pfad-Gewichte auf Personenebene
# ------------------------------------------------------------

id_w <- item_profile %>%
  distinct(id, resp_path) %>%
  group_by(resp_path) %>%
  mutate(n_path = n()) %>%
  ungroup() %>%
  mutate(w = 1 / n_path) %>%
  select(id, resp_path, n_path, w)

# ------------------------------------------------------------
# 2) Analysedatensätze für H1 / H2 / H3
# ------------------------------------------------------------

# H1: Post-Fake-Urteil
dat_judgment <- item_profile %>%
  filter(
    post_defined,
    pre_choice %in% c("real", "fake"),
    post_choice %in% c("real", "fake"),
    !is.na(source), !is.na(veracity), !is.na(text_id)
  ) %>%
  left_join(id_w, by = "id") %>%
  mutate(
    source_f   = factor(source, levels = c("OKI", "KI")),
    veracity_f = factor(veracity, levels = c("Real", "Fake")),
    post_fake  = as.integer(post_choice == "fake")
  )

# H2/H3: Confidence-Change bei stabilen Urteilen
dat_conf_same <- item_profile %>%
  filter(
    post_defined,
    pre_choice %in% c("real", "fake"),
    post_choice %in% c("real", "fake"),
    pre_choice == post_choice,
    !is.na(pre_conf), !is.na(post_conf),
    !is.na(source), !is.na(veracity), !is.na(text_id)
  ) %>%
  left_join(id_w, by = "id") %>%
  mutate(
    source_f   = factor(source, levels = c("OKI", "KI")),
    veracity_f = factor(veracity, levels = c("Real", "Fake")),
    conf_change_same_judgment = post_conf - pre_conf
  )

# Optional: Missingness-Report
conf_missing_report <- item_profile %>%
  summarise(
    n_items = n(),
    share_post_skipped_by_design = mean(post_by_design_skipped, na.rm = TRUE),
    pre_wn_rate_all = mean(pre_choice == "wn", na.rm = TRUE),
    post_defined_rate = mean(post_defined, na.rm = TRUE),
    post_conf_missing_rate_given_post = mean(post_defined & post_conf_missing_given_choice, na.rm = TRUE),
    pre_conf_missing_rate_given_choice = mean(pre_conf_missing_given_choice, na.rm = TRUE)
  )

conf_missing_report

# ------------------------------------------------------------
# 3) Robuste SE + Hilfsfunktionen
# ------------------------------------------------------------

robust_vcov <- function(model, cluster_vec) {
  sandwich::vcovCL(model, cluster = cluster_vec, type = "HC1")
}

robust_test <- function(model, cluster_vec) {
  V  <- robust_vcov(model, cluster_vec)
  ct <- lmtest::coeftest(model, vcov = V)
  ct <- as.matrix(ct)
  tibble(
    term     = rownames(ct),
    estimate = as.numeric(ct[, 1]),
    se       = as.numeric(ct[, 2]),
    stat     = as.numeric(ct[, 3]),
    p        = as.numeric(ct[, 4])
  )
}

lincombo_robust <- function(model, cluster_vec, coefs_named) {
  b <- coef(model)
  V <- robust_vcov(model, cluster_vec)
  common <- intersect(names(coefs_named), names(b))
  a <- rep(0, length(b)); names(a) <- names(b)
  a[common] <- coefs_named[common]
  est <- sum(a * b)
  se  <- as.numeric(sqrt(t(a) %*% V %*% a))
  stat <- est / se
  p <- 2 * (1 - pnorm(abs(stat)))
  tibble(term = "lincombo", estimate = est, se = se, stat = stat, p = p)
}

simple_effect_ki_at_fake <- function(model, cluster_vec) {
  lincombo_robust(
    model, cluster_vec,
    c("source_fKI" = 1, "source_fKI:veracity_fFake" = 1)
  ) %>%
    mutate(term = "KI effect at veracity=Fake (β_KI_Fake = β_KI + β_int)")
}

add_ci_linear <- function(tbl, level = 0.95) {
  z <- qnorm(1 - (1 - level) / 2)
  tbl %>%
    mutate(
      ci_lower = estimate - z * se,
      ci_upper = estimate + z * se
    )
}

add_or_ci_logit <- function(tbl, level = 0.95) {
  z <- qnorm(1 - (1 - level) / 2)
  tbl %>%
    mutate(
      ci_lower = estimate - z * se,
      ci_upper = estimate + z * se,
      OR = exp(estimate),
      OR_ci_lower = exp(ci_lower),
      OR_ci_upper = exp(ci_upper)
    )
}

# ------------------------------------------------------------
# 4) H1 – KI-Labels erhöhen Wahrscheinlichkeit eines Fake-Urteils
# H1-Haupttest: Source + Veracity (ohne Interaktion)
# Design-Check: Source × Veracity
# ------------------------------------------------------------

# Haupttest H1
m_h1_main_w <- glm(
  post_fake ~ source_f + veracity_f + factor(id) + factor(text_id),
  data = dat_judgment,
  family = binomial(),
  weights = w
)

m_h1_main_nw <- glm(
  post_fake ~ source_f + veracity_f + factor(id) + factor(text_id),
  data = dat_judgment,
  family = binomial()
)

# Design-Check H1
m_h1_mod_w <- glm(
  post_fake ~ source_f * veracity_f + factor(id) + factor(text_id),
  data = dat_judgment,
  family = binomial(),
  weights = w
)

m_h1_mod_nw <- glm(
  post_fake ~ source_f * veracity_f + factor(id) + factor(text_id),
  data = dat_judgment,
  family = binomial()
)

h1_main_w_robust <- robust_test(m_h1_main_w, dat_judgment$id)
h1_main_nw_robust <- robust_test(m_h1_main_nw, dat_judgment$id)
h1_mod_w_robust <- robust_test(m_h1_mod_w, dat_judgment$id)
h1_mod_nw_robust <- robust_test(m_h1_mod_nw, dat_judgment$id)

h1_main_w_robust_ci <- add_or_ci_logit(h1_main_w_robust)
h1_main_nw_robust_ci <- add_or_ci_logit(h1_main_nw_robust)
h1_mod_w_robust_ci <- add_or_ci_logit(h1_mod_w_robust)
h1_mod_nw_robust_ci <- add_or_ci_logit(h1_mod_nw_robust)

# Optional: Simple Effect bei Fake-Stimuli aus Interaktionsmodell
h1_mod_w_simple_fake <- simple_effect_ki_at_fake(m_h1_mod_w, dat_judgment$id)
h1_mod_nw_simple_fake <- simple_effect_ki_at_fake(m_h1_mod_nw, dat_judgment$id)

h1_mod_w_simple_fake_ci <- add_or_ci_logit(h1_mod_w_simple_fake)
h1_mod_nw_simple_fake_ci <- add_or_ci_logit(h1_mod_nw_simple_fake)

# ------------------------------------------------------------
# 5) H2 – KI-Labels senken Selbstsicherheit bei stabilen Urteilen
# H2-Haupttest: Source + Veracity (ohne Interaktion)
# Design-Check: Source × Veracity
# ------------------------------------------------------------

# Haupttest H2
m_h2_main_w <- lm(
  conf_change_same_judgment ~ source_f + veracity_f + factor(id) + factor(text_id),
  data = dat_conf_same,
  weights = w
)

m_h2_main_nw <- lm(
  conf_change_same_judgment ~ source_f + veracity_f + factor(id) + factor(text_id),
  data = dat_conf_same
)

# Design-Check H2
m_h2_mod_w <- lm(
  conf_change_same_judgment ~ source_f * veracity_f + factor(id) + factor(text_id),
  data = dat_conf_same,
  weights = w
)

m_h2_mod_nw <- lm(
  conf_change_same_judgment ~ source_f * veracity_f + factor(id) + factor(text_id),
  data = dat_conf_same
)

h2_main_w_robust <- robust_test(m_h2_main_w, dat_conf_same$id)
h2_main_nw_robust <- robust_test(m_h2_main_nw, dat_conf_same$id)
h2_mod_w_robust <- robust_test(m_h2_mod_w, dat_conf_same$id)
h2_mod_nw_robust <- robust_test(m_h2_mod_nw, dat_conf_same$id)

h2_main_w_robust_ci <- add_ci_linear(h2_main_w_robust)
h2_main_nw_robust_ci <- add_ci_linear(h2_main_nw_robust)
h2_mod_w_robust_ci <- add_ci_linear(h2_mod_w_robust)
h2_mod_nw_robust_ci <- add_ci_linear(h2_mod_nw_robust)

# Optional: Simple Effect bei Fake-Stimuli aus Interaktionsmodell
h2_mod_w_simple_fake <- simple_effect_ki_at_fake(m_h2_mod_w, dat_conf_same$id)
h2_mod_nw_simple_fake <- simple_effect_ki_at_fake(m_h2_mod_nw, dat_conf_same$id)

h2_mod_w_simple_fake_ci <- add_ci_linear(h2_mod_w_simple_fake)
h2_mod_nw_simple_fake_ci <- add_ci_linear(h2_mod_nw_simple_fake)

# ------------------------------------------------------------
# 6) H3 – OKI-Labels erhöhen Selbstsicherheit bei stabilen Urteilen
# KORRIGIERT:
# - nur OKI-Subset
# - Stimulus-FE mit Sum-Kontrasten
# - Intercept = über Stimuli kontrolliertes Gesamtmittel
# - einseitiger Test auf Δ > 0
# ------------------------------------------------------------

dat_h3_human_mean <- dat_conf_same %>%
  filter(source_f == "OKI") %>%
  mutate(text_id_f = factor(text_id))

contrasts(dat_h3_human_mean$text_id_f) <- contr.sum(nlevels(dat_h3_human_mean$text_id_f))

m_h3_human_mean_w <- lm(
  conf_change_same_judgment ~ text_id_f,
  data = dat_h3_human_mean,
  weights = w
)

m_h3_human_mean_nw <- lm(
  conf_change_same_judgment ~ text_id_f,
  data = dat_h3_human_mean
)

h3_human_mean_w_robust <- robust_test(m_h3_human_mean_w, dat_h3_human_mean$id)
h3_human_mean_nw_robust <- robust_test(m_h3_human_mean_nw, dat_h3_human_mean$id)

h3_human_mean_w_robust_ci <- add_ci_linear(h3_human_mean_w_robust)
h3_human_mean_nw_robust_ci <- add_ci_linear(h3_human_mean_nw_robust)

# ------------------------------------------------------------
# 7) H3 – einseitige Auswertung (Δ > 0)
# ------------------------------------------------------------

one_sided_p_gt0 <- function(estimate, se) {
  z <- estimate / se
  1 - pnorm(z)
}

one_sided_lb_95 <- function(estimate, se) {
  estimate - 1.645 * se
}

h3_one_sided_summary <- function(rob_tbl, label) {
  x <- rob_tbl %>% filter(term == "(Intercept)")
  stopifnot(nrow(x) == 1)
  est <- x$estimate
  se  <- x$se
  tibble(
    model = label,
    term = "(Intercept)",
    estimate = est,
    se = se,
    stat = est / se,
    p_two_sided = x$p,
    p_one_sided_gt0 = one_sided_p_gt0(est, se),
    ci_lower = est - 1.96 * se,
    ci_upper = est + 1.96 * se,
    lb_one_sided_95 = one_sided_lb_95(est, se)
  )
}

h3_w_one  <- h3_one_sided_summary(h3_human_mean_w_robust,  "H3_OKI_W")
h3_nw_one <- h3_one_sided_summary(h3_human_mean_nw_robust, "H3_OKI_NW")

# ------------------------------------------------------------
# 8) Decision Table
# H1/H2:
# - Haupttest = Modelle ohne Interaktion
# - Interaktion = separater Design-Check
# ------------------------------------------------------------

get_term_row <- function(tbl, term_name) {
  x <- tbl %>% filter(term == term_name)
  if (nrow(x) == 0) {
    return(tibble(
      term = term_name,
      estimate = NA_real_,
      se = NA_real_,
      stat = NA_real_,
      p = NA_real_
    ))
  }
  x %>% slice(1)
}

make_decision <- function(estimate, p, direction = c("positive", "negative"), alpha = 0.05) {
  direction <- match.arg(direction)
  
  if (is.na(estimate) || is.na(p)) return(NA_character_)
  if (p >= alpha) return("nicht unterstützt")
  
  if (direction == "positive" && estimate > 0) return("unterstützt")
  if (direction == "negative" && estimate < 0) return("unterstützt")
  
  return("nicht unterstützt")
}

# H1-Haupttest
h1_w_main <- get_term_row(h1_main_w_robust_ci, "source_fKI")
h1_nw_main <- get_term_row(h1_main_nw_robust_ci, "source_fKI")

# H1-Interaktion
h1_w_int  <- get_term_row(h1_mod_w_robust_ci, "source_fKI:veracity_fFake")
h1_nw_int <- get_term_row(h1_mod_nw_robust_ci, "source_fKI:veracity_fFake")

# H2-Haupttest
h2_w_main <- get_term_row(h2_main_w_robust_ci, "source_fKI")
h2_nw_main <- get_term_row(h2_main_nw_robust_ci, "source_fKI")

# H2-Interaktion
h2_w_int  <- get_term_row(h2_mod_w_robust_ci, "source_fKI:veracity_fFake")
h2_nw_int <- get_term_row(h2_mod_nw_robust_ci, "source_fKI:veracity_fFake")

decision_table_main <- bind_rows(
  tibble(
    hypothesis = "H1",
    analysis = "gewichtet",
    effect = "Allgemeiner KI-Effekt auf Fake-Urteil",
    estimate = h1_w_main$estimate,
    se = h1_w_main$se,
    p = h1_w_main$p,
    ci_lower = h1_w_main$ci_lower,
    ci_upper = h1_w_main$ci_upper,
    OR = h1_w_main$OR,
    OR_ci_lower = h1_w_main$OR_ci_lower,
    OR_ci_upper = h1_w_main$OR_ci_upper,
    decision = make_decision(h1_w_main$estimate, h1_w_main$p, direction = "positive")
  ),
  tibble(
    hypothesis = "H1",
    analysis = "ungewichtet",
    effect = "Allgemeiner KI-Effekt auf Fake-Urteil",
    estimate = h1_nw_main$estimate,
    se = h1_nw_main$se,
    p = h1_nw_main$p,
    ci_lower = h1_nw_main$ci_lower,
    ci_upper = h1_nw_main$ci_upper,
    OR = h1_nw_main$OR,
    OR_ci_lower = h1_nw_main$OR_ci_lower,
    OR_ci_upper = h1_nw_main$OR_ci_upper,
    decision = make_decision(h1_nw_main$estimate, h1_nw_main$p, direction = "positive")
  ),
  tibble(
    hypothesis = "H2",
    analysis = "gewichtet",
    effect = "Allgemeiner KI-Effekt auf Confidence-Change (stabil)",
    estimate = h2_w_main$estimate,
    se = h2_w_main$se,
    p = h2_w_main$p,
    ci_lower = h2_w_main$ci_lower,
    ci_upper = h2_w_main$ci_upper,
    OR = NA_real_,
    OR_ci_lower = NA_real_,
    OR_ci_upper = NA_real_,
    decision = make_decision(h2_w_main$estimate, h2_w_main$p, direction = "negative")
  ),
  tibble(
    hypothesis = "H2",
    analysis = "ungewichtet",
    effect = "Allgemeiner KI-Effekt auf Confidence-Change (stabil)",
    estimate = h2_nw_main$estimate,
    se = h2_nw_main$se,
    p = h2_nw_main$p,
    ci_lower = h2_nw_main$ci_lower,
    ci_upper = h2_nw_main$ci_upper,
    OR = NA_real_,
    OR_ci_lower = NA_real_,
    OR_ci_upper = NA_real_,
    decision = make_decision(h2_nw_main$estimate, h2_nw_main$p, direction = "negative")
  ),
  tibble(
    hypothesis = "H3",
    analysis = "gewichtet",
    effect = "Grand Mean > 0 im OKI-Subset (einseitig)",
    estimate = h3_w_one$estimate,
    se = h3_w_one$se,
    p = h3_w_one$p_one_sided_gt0,
    ci_lower = h3_w_one$ci_lower,
    ci_upper = h3_w_one$ci_upper,
    OR = NA_real_,
    OR_ci_lower = NA_real_,
    OR_ci_upper = NA_real_,
    decision = make_decision(h3_w_one$estimate, h3_w_one$p_one_sided_gt0, direction = "positive")
  ),
  tibble(
    hypothesis = "H3",
    analysis = "ungewichtet",
    effect = "Grand Mean > 0 im OKI-Subset (einseitig)",
    estimate = h3_nw_one$estimate,
    se = h3_nw_one$se,
    p = h3_nw_one$p_one_sided_gt0,
    ci_lower = h3_nw_one$ci_lower,
    ci_upper = h3_nw_one$ci_upper,
    OR = NA_real_,
    OR_ci_lower = NA_real_,
    OR_ci_upper = NA_real_,
    decision = make_decision(h3_nw_one$estimate, h3_nw_one$p_one_sided_gt0, direction = "positive")
  )
)

decision_table_moderation <- bind_rows(
  tibble(
    hypothesis = "H1",
    analysis = "gewichtet",
    effect = "Design-Check: Interaktion KI × Veracity",
    estimate = h1_w_int$estimate,
    se = h1_w_int$se,
    p = h1_w_int$p,
    ci_lower = h1_w_int$ci_lower,
    ci_upper = h1_w_int$ci_upper,
    OR = h1_w_int$OR,
    OR_ci_lower = h1_w_int$OR_ci_lower,
    OR_ci_upper = h1_w_int$OR_ci_upper,
    decision = ifelse(!is.na(h1_w_int$p) & h1_w_int$p < 0.05, "Interaktion signifikant", "keine Evidenz für Interaktion")
  ),
  tibble(
    hypothesis = "H1",
    analysis = "ungewichtet",
    effect = "Design-Check: Interaktion KI × Veracity",
    estimate = h1_nw_int$estimate,
    se = h1_nw_int$se,
    p = h1_nw_int$p,
    ci_lower = h1_nw_int$ci_lower,
    ci_upper = h1_nw_int$ci_upper,
    OR = h1_nw_int$OR,
    OR_ci_lower = h1_nw_int$OR_ci_lower,
    OR_ci_upper = h1_nw_int$OR_ci_upper,
    decision = ifelse(!is.na(h1_nw_int$p) & h1_nw_int$p < 0.05, "Interaktion signifikant", "keine Evidenz für Interaktion")
  ),
  tibble(
    hypothesis = "H2",
    analysis = "gewichtet",
    effect = "Design-Check: Interaktion KI × Veracity",
    estimate = h2_w_int$estimate,
    se = h2_w_int$se,
    p = h2_w_int$p,
    ci_lower = h2_w_int$ci_lower,
    ci_upper = h2_w_int$ci_upper,
    OR = NA_real_,
    OR_ci_lower = NA_real_,
    OR_ci_upper = NA_real_,
    decision = ifelse(!is.na(h2_w_int$p) & h2_w_int$p < 0.05, "Interaktion signifikant", "keine Evidenz für Interaktion")
  ),
  tibble(
    hypothesis = "H2",
    analysis = "ungewichtet",
    effect = "Design-Check: Interaktion KI × Veracity",
    estimate = h2_nw_int$estimate,
    se = h2_nw_int$se,
    p = h2_nw_int$p,
    ci_lower = h2_nw_int$ci_lower,
    ci_upper = h2_nw_int$ci_upper,
    OR = NA_real_,
    OR_ci_lower = NA_real_,
    OR_ci_upper = NA_real_,
    decision = ifelse(!is.na(h2_nw_int$p) & h2_nw_int$p < 0.05, "Interaktion signifikant", "keine Evidenz für Interaktion")
  )
)

decision_summary_primary <- decision_table_main %>%
  filter(analysis == "gewichtet") %>%
  transmute(
    hypothesis,
    primary_effect = effect,
    estimate,
    se,
    p,
    ci_lower,
    ci_upper,
    OR,
    OR_ci_lower,
    OR_ci_upper,
    decision
  )

# ------------------------------------------------------------
# 9) Ausgabe
# ------------------------------------------------------------

cat("\n==============================\n")
cat("HYPOTHESENTESTS H1–H3\n")
cat("==============================\n\n")

cat("---- Missingness / Datenbasis ----\n")
print(conf_missing_report); cat("\n")

cat("---- H1 Haupttest: allgemeiner KI-Effekt auf Fake-Urteil (mit OR + 95%-KI) ----\n")
print(h1_main_w_robust_ci); cat("\n")
print(h1_main_nw_robust_ci); cat("\n")

cat("---- H1 Design-Check: Interaktion Source × Veracity (mit OR + 95%-KI) ----\n")
print(h1_mod_w_robust_ci); cat("\n")
print(h1_mod_nw_robust_ci); cat("\n")

cat("---- H1 Optional: KI-Effekt bei Fake-Stimuli aus Interaktionsmodell ----\n")
print(h1_mod_w_simple_fake_ci); cat("\n")
print(h1_mod_nw_simple_fake_ci); cat("\n")

cat("---- H2 Haupttest: allgemeiner KI-Effekt auf Confidence-Change (mit 95%-KI) ----\n")
print(h2_main_w_robust_ci); cat("\n")
print(h2_main_nw_robust_ci); cat("\n")

cat("---- H2 Design-Check: Interaktion Source × Veracity (mit 95%-KI) ----\n")
print(h2_mod_w_robust_ci); cat("\n")
print(h2_mod_nw_robust_ci); cat("\n")

cat("---- H2 Optional: KI-Effekt bei Fake-Stimuli aus Interaktionsmodell ----\n")
print(h2_mod_w_simple_fake_ci); cat("\n")
print(h2_mod_nw_simple_fake_ci); cat("\n")

cat("---- H3: OKI-Subset -> Grand Mean > 0 ----\n")
print(h3_human_mean_w_robust_ci); cat("\n")
print(h3_human_mean_nw_robust_ci); cat("\n")
print(h3_w_one); cat("\n")
print(h3_nw_one); cat("\n")

cat("---- Decision Table ----\n")
print(decision_table_main); cat("\n")
print(decision_table_moderation); cat("\n")
print(decision_summary_primary); cat("\n")