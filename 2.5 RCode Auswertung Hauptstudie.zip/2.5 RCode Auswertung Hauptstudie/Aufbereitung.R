# ---------------------------- #
# 0) Pakete
# ---------------------------- #
library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(janitor)
library(forcats)
library(tibble)
library(sandwich)
library(lmtest)

# ---------------------------- #
# 1) Einlesen
# ---------------------------- #
file_path <- "C:/Users/annai/Downloads/Wahrnehmung_und_Bewertung_von_Nachrichteninhalten.xlsx"

Alle  <- read_excel(file_path, sheet = "Alles")
pfad1 <- read_excel(file_path, sheet = "Pfad1")
pfad2 <- read_excel(file_path, sheet = "Pfad2")
pfad3 <- read_excel(file_path, sheet = "Pfad3")
pfad4 <- read_excel(file_path, sheet = "Pfad4")

# ---------------------------- #
# 2) Spaltenzuordnung (exakt wie im Export)
# ---------------------------- #
col_id     <- "Teilnehmer"
col_age    <- "Wie alt sind Sie?"
col_gender <- "Was ist Ihr Geschlecht?"
col_media  <- "Beschreiben Sie Ihre Mediennutzung (Soziale Medien und Nachrichtendienste, digital und Print) in Stunden pro Woche. Es geht nicht um die gesamte Bildschirmzeit."
col_edu    <- "Was ist Ihr höchster Bildungsabschluss?"

need_cols <- c(col_id, col_age, col_gender, col_media, col_edu)

stopifnot(all(need_cols %in% names(Alle)))
stopifnot(all(need_cols %in% names(pfad1)))
stopifnot(all(need_cols %in% names(pfad2)))
stopifnot(all(need_cols %in% names(pfad3)))
stopifnot(all(need_cols %in% names(pfad4)))