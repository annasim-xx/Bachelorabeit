# ============================================================
# TEIL A – DEMOGRAPHIE (Alle + Pfad1-4)
# ============================================================

# ----------------------------
# A1) Recode-Funktionen (Mediennutzung / Bildung)
# ----------------------------
recode_media <- function(x) {
  x0 <- x %>% as.character() %>% str_squish()
  lev <- c(
    "Bis zu 1 Stunde",
    "Bis zu 2 Stunden",
    "Bis zu 3 Stunden",
    "Bis zu 7 Stunden",
    "Bis zu 10 Stunden",
    "Bis zu 17 Stunden",
    "Bis zu 24 Stunden",
    "Bis zu 31 Stunden",
    "Über 31 Stunden",
    "Unsicher"
  )
  out <- case_when(
    str_detect(x0, regex("unsicher", ignore_case = TRUE)) ~ "Unsicher",
    str_detect(x0, regex("über\\s*31|ueber\\s*31", ignore_case = TRUE)) ~ "Über 31 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*31", ignore_case = TRUE)) ~ "Bis zu 31 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*24", ignore_case = TRUE)) ~ "Bis zu 24 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*17", ignore_case = TRUE)) ~ "Bis zu 17 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*10", ignore_case = TRUE)) ~ "Bis zu 10 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*7",  ignore_case = TRUE)) ~ "Bis zu 7 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*3",  ignore_case = TRUE)) ~ "Bis zu 3 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*2",  ignore_case = TRUE)) ~ "Bis zu 2 Stunden",
    str_detect(x0, regex("bis\\s*zu\\s*1",  ignore_case = TRUE)) ~ "Bis zu 1 Stunde",
    TRUE ~ NA_character_
  )
  factor(out, levels = lev, ordered = TRUE)
}

recode_edu <- function(x) {
  x0 <- x %>% as.character() %>% str_squish()
  lev <- c(
    "kein Abschluss",
    "Hauptschule",
    "Realschule",
    "Fachhochschulreife",
    "Allgemeine Hochschulreife (Abitur)",
    "Berufsausbildung",
    "Fachwirt IHK",
    "Betriebswirt IHK",
    "Bachelor",
    "Diplom",
    "Master",
    "Promotion",
    "Anderer"
  )
  out <- case_when(
    str_detect(x0, regex("^kein|kein\\s+abschluss", ignore_case = TRUE)) ~ "kein Abschluss",
    str_detect(x0, regex("haupt", ignore_case = TRUE)) ~ "Hauptschule",
    str_detect(x0, regex("real", ignore_case = TRUE)) ~ "Realschule",
    str_detect(x0, regex("fachhochschulreife|fhr", ignore_case = TRUE)) ~ "Fachhochschulreife",
    str_detect(x0, regex("allgemeine\\s+hochschulreife|abitur", ignore_case = TRUE)) ~ "Allgemeine Hochschulreife (Abitur)",
    str_detect(x0, regex("berufsausbildung|ausbildung", ignore_case = TRUE)) ~ "Berufsausbildung",
    str_detect(x0, regex("fachwirt", ignore_case = TRUE)) ~ "Fachwirt IHK",
    str_detect(x0, regex("betriebswirt", ignore_case = TRUE)) ~ "Betriebswirt IHK",
    str_detect(x0, regex("bachelor", ignore_case = TRUE)) ~ "Bachelor",
    str_detect(x0, regex("diplom", ignore_case = TRUE)) ~ "Diplom",
    str_detect(x0, regex("master", ignore_case = TRUE)) ~ "Master",
    str_detect(x0, regex("promotion|doktor", ignore_case = TRUE)) ~ "Promotion",
    str_detect(x0, regex("ander", ignore_case = TRUE)) ~ "Anderer",
    TRUE ~ NA_character_
  )
  factor(out, levels = lev)
}

median_ord_level <- function(f) {
  x <- f[!is.na(f) & as.character(f) != "Unsicher"]
  if (length(x) == 0) return(NA_character_)
  idx <- sort(as.numeric(x))
  levels(f)[idx[ceiling(length(idx) / 2)]]
}

top_open_midpoint <- 35
media_midpoint <- function(media_cat_chr) {
  case_when(
    media_cat_chr == "Bis zu 1 Stunde"   ~ 0.5,
    media_cat_chr == "Bis zu 2 Stunden"  ~ 1.5,
    media_cat_chr == "Bis zu 3 Stunden"  ~ 2.5,
    media_cat_chr == "Bis zu 7 Stunden"  ~ 5.0,
    media_cat_chr == "Bis zu 10 Stunden" ~ 8.5,
    media_cat_chr == "Bis zu 17 Stunden" ~ 13.5,
    media_cat_chr == "Bis zu 24 Stunden" ~ 20.5,
    media_cat_chr == "Bis zu 31 Stunden" ~ 27.5,
    media_cat_chr == "Über 31 Stunden"   ~ top_open_midpoint,
    TRUE ~ NA_real_
  )
}

# ----------------------------
# A2) Helper: Demographie-Tibble pro Datensatz bauen
# ----------------------------
build_demo <- function(dat, group_label, path_label = NA_integer_) {
  dat %>%
    transmute(
      group      = group_label,
      path_sheet = path_label,
      id         = .data[[col_id]],
      age        = suppressWarnings(as.numeric(.data[[col_age]])),
      gender_raw = as.character(.data[[col_gender]]) %>% str_squish(),
      media_raw  = as.character(.data[[col_media]])  %>% str_squish(),
      edu_raw    = as.character(.data[[col_edu]])    %>% str_squish()
    ) %>%
    mutate(
      media_cat = recode_media(media_raw),
      edu_cat   = recode_edu(edu_raw),
      
      edu_group = case_when(
        edu_cat %in% c("kein Abschluss","Hauptschule","Realschule","Fachhochschulreife","Allgemeine Hochschulreife (Abitur)") ~ "Schule",
        edu_cat %in% c("Berufsausbildung","Fachwirt IHK","Betriebswirt IHK") ~ "Beruflich",
        edu_cat %in% c("Bachelor","Diplom","Master","Promotion") ~ "Akademisch",
        edu_cat %in% c("Anderer") ~ "Anderer",
        TRUE ~ NA_character_
      ),
      
      is_academic   = edu_cat %in% c("Bachelor","Diplom","Master","Promotion"),
      is_abi_fhr    = edu_cat %in% c("Fachhochschulreife","Allgemeine Hochschulreife (Abitur)"),
      is_vocational = edu_cat %in% c("Berufsausbildung","Fachwirt IHK","Betriebswirt IHK"),
      
      media_unsure  = as.character(media_cat) == "Unsicher",
      media_hours_approx = media_midpoint(as.character(media_cat))
    )
}

demo_all <- bind_rows(
  build_demo(Alle,  "Alle",  NA_integer_),
  build_demo(pfad1, "Pfad1", 1),
  build_demo(pfad2, "Pfad2", 2),
  build_demo(pfad3, "Pfad3", 3),
  build_demo(pfad4, "Pfad4", 4)
)

demo_main <- demo_all %>%
  filter(group == "Alle") %>%
  distinct(id, .keep_all = TRUE) %>%
  mutate(
    gender = na_if(gender_raw, "") %>% str_to_lower(),
    gender = case_when(
      str_detect(gender, "weib") ~ "weiblich",
      str_detect(gender, "männ|maenn") ~ "männlich",
      str_detect(gender, "div|nichtbin|non") ~ "divers",
      TRUE ~ gender
    ),
    gender_f = factor(gender),
    edu_group_f = factor(edu_group, levels = c("Schule","Beruflich","Akademisch","Anderer")),
    media_hours = ifelse(media_unsure, NA_real_, media_hours_approx),
    age_z = as.numeric(scale(age)),
    media_hours_z = as.numeric(scale(media_hours))
  ) %>%
  select(id, age, age_z, gender_f, edu_group_f, media_cat, media_hours, media_hours_z)

# ----------------------------
# A3) Demographie-Tabellen
# ----------------------------
n_by_group <- demo_all %>% count(group, name = "n")

age_by_group <- demo_all %>%
  group_by(group) %>%
  summarise(
    n = n(),
    n_age = sum(!is.na(age)),
    mean = mean(age, na.rm = TRUE),
    sd = sd(age, na.rm = TRUE),
    median = median(age, na.rm = TRUE),
    iqr = IQR(age, na.rm = TRUE),
    min = min(age, na.rm = TRUE),
    max = max(age, na.rm = TRUE),
    .groups = "drop"
  )

gender_by_group <- demo_all %>%
  mutate(gender_raw = na_if(gender_raw, "")) %>%
  count(group, gender_raw, name = "n") %>%
  group_by(group) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup() %>%
  arrange(group, desc(n))

media_freq_by_group <- demo_all %>%
  count(group, media_cat, name = "n") %>%
  group_by(group) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup() %>%
  arrange(group, media_cat)

media_summary_by_group <- demo_all %>%
  group_by(group) %>%
  summarise(
    n = n(),
    n_valid = sum(!is.na(media_cat) & as.character(media_cat) != "Unsicher"),
    median_cat = median_ord_level(media_cat),
    share_unsure = mean(media_unsure, na.rm = TRUE),
    .groups = "drop"
  )

media_hours_by_group <- demo_all %>%
  filter(!is.na(media_hours_approx), !media_unsure) %>%
  group_by(group) %>%
  summarise(
    n = n(),
    mean = mean(media_hours_approx),
    sd = sd(media_hours_approx),
    median = median(media_hours_approx),
    iqr = IQR(media_hours_approx),
    min = min(media_hours_approx),
    max = max(media_hours_approx),
    .groups = "drop"
  )

edu_freq_by_group <- demo_all %>%
  count(group, edu_cat, name = "n") %>%
  group_by(group) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup() %>%
  arrange(group, edu_cat)

edu_group_freq_by_group <- demo_all %>%
  count(group, edu_group, name = "n") %>%
  group_by(group) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup() %>%
  arrange(group, edu_group)

edu_indicators_by_group <- demo_all %>%
  group_by(group) %>%
  summarise(
    share_academic = mean(is_academic, na.rm = TRUE),
    share_abi_fhr = mean(is_abi_fhr, na.rm = TRUE),
    share_vocational = mean(is_vocational, na.rm = TRUE),
    .groups = "drop"
  )

missing_by_group <- demo_all %>%
  group_by(group) %>%
  summarise(
    n = n(),
    miss_age = mean(is.na(age)),
    miss_gender = mean(is.na(gender_raw) | gender_raw == ""),
    miss_media = mean(is.na(media_cat)),
    miss_edu = mean(is.na(edu_cat)),
    .groups = "drop"
  )

n_by_group
age_by_group
gender_by_group
media_freq_by_group
media_summary_by_group
media_hours_by_group
edu_freq_by_group
edu_group_freq_by_group
edu_indicators_by_group
missing_by_group

# ============================================================
# TEIL B – ITEM-DATEN (Sheet "Alles"): WIDE -> LONG -> ITEMS
# ============================================================

item_regex <- regex(
  "^p\\s*([1-4])\\s*[\\._\\- ]*\\s*([1-8])\\s*\\.\\s*(1|2a|2b|3|4a|4b)\\b",
  ignore_case = TRUE
)

item_cols <- names(Alle)[str_detect(names(Alle), item_regex)]
stopifnot(length(item_cols) > 0)

to_chr <- function(x) ifelse(is.na(x), NA_character_, as.character(x))
to_num <- function(x) suppressWarnings(as.numeric(gsub(",", ".", as.character(x))))

long_raw <- Alle %>%
  transmute(
    id = .data[[col_id]],
    across(all_of(item_cols), identity)
  ) %>%
  pivot_longer(
    cols = all_of(item_cols),
    names_to = "var",
    values_to = "value"
  ) %>%
  mutate(
    value_chr = to_chr(value) %>% str_squish(),
    m = str_match(var, item_regex),
    path = as.integer(m[, 2]),
    news = as.integer(m[, 3]),
    measure = m[, 4],
    time = case_when(
      measure %in% c("1", "2a", "2b") ~ "pre",
      measure %in% c("3", "4a", "4b") ~ "post",
      TRUE ~ NA_character_
    ),
    is_skipped = str_detect(value_chr, regex("^\\s*übersprungen\\s*$", ignore_case = TRUE)),
    is_missing = is.na(value_chr) | value_chr == ""
  ) %>%
  select(-m)

seen_tbl <- long_raw %>%
  group_by(id, path, news) %>%
  summarise(
    seen_item = any(!is_skipped & !is_missing),
    all_skipped = all(is_skipped | is_missing),
    .groups = "drop"
  )

long <- long_raw %>%
  left_join(seen_tbl, by = c("id", "path", "news")) %>%
  mutate(
    skipped_structural = !seen_item & all_skipped,
    missing_true = seen_item & is_missing & !is_skipped
  )

resp_path_tbl <- seen_tbl %>%
  group_by(id, path) %>%
  summarise(n_seen = sum(seen_item), .groups = "drop") %>%
  group_by(id) %>%
  slice_max(order_by = n_seen, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  select(id, resp_path = path, n_seen)

long <- long %>%
  left_join(resp_path_tbl, by = "id")

mapping <- tibble::tribble(
  ~path, ~news, ~cell_raw,
  1, 1, "OKI.real",   2, 1, "OKI.fake",   3, 1, "KI.real",  4, 1, "KI.fake",
  1, 2, "OKI.fake",   2, 2, "KI.real",  3, 2, "KI.fake",  4, 2, "OKI.real",
  1, 3, "KI.real",  2, 3, "KI.fake",  3, 3, "OKI.real",   4, 3, "OKI.fake",
  1, 4, "KI.fake",  2, 4, "OKI.real",   3, 4, "OKI.fake",   4, 4, "KI.real",
  1, 5, "OKI.real",   2, 5, "OKI.fake",   3, 5, "KI.real",  4, 5, "KI.fake",
  1, 6, "OKI.fake",   2, 6, "KI.real",  3, 6, "KI.fake",  4, 6, "OKI.real",
  1, 7, "KI.real",  2, 7, "KI.fake",  3, 7, "OKI.real",   4, 7, "OKI.fake",
  1, 8, "KI.fake",  2, 8, "OKI.real",   3, 8, "OKI.fake",   4, 8, "KI.real"
) %>%
  mutate(
    cell = str_to_lower(cell_raw),
    source = case_when(
      str_detect(cell_raw, regex("^ki\\.", ignore_case = TRUE)) ~ "KI",
      str_detect(cell_raw, regex("^m\\.", ignore_case = TRUE))  ~ "OKI",
      TRUE ~ NA_character_
    ),
    veracity = case_when(
      str_detect(cell_raw, regex("\\.real$", ignore_case = TRUE)) ~ "Real",
      str_detect(cell_raw, regex("\\.fake$", ignore_case = TRUE)) ~ "Fake",
      TRUE ~ NA_character_
    ),
    text_id = news
  ) %>%
  select(path, news, text_id, source, veracity, cell)

cell_levels <- c("OKI.real", "OKI.fake", "ki.real", "ki.fake")
mapping <- mapping %>%
  mutate(
    cell_factor = factor(cell, levels = cell_levels),
    cell_index = as.integer(cell_factor),
    text_id_32 = (text_id - 1L) * 4L + cell_index
  ) %>%
  select(-cell_factor, -cell_index)

long <- long %>%
  left_join(mapping, by = c("path", "news"))

recode_choice <- function(x) {
  x0 <- to_chr(x) %>% str_squish() %>% str_to_lower()
  case_when(
    str_detect(x0, "weiß|weiss|unsicher|kann\\s*ich\\s*nicht|keine\\s*ahnung") ~ "wn",
    str_detect(x0, "fake|falsch") ~ "fake",
    str_detect(x0, "real|echt|wahr") ~ "real",
    TRUE ~ NA_character_
  )
}

items <- long %>%
  filter(seen_item) %>%
  select(id, resp_path, path, news, text_id, text_id_32, source, veracity, cell, measure, value_chr) %>%
  pivot_wider(
    names_from = measure,
    values_from = value_chr,
    names_prefix = "m_"
  ) %>%
  mutate(
    pre_choice_raw  = m_1,
    post_choice_raw = m_3,
    pre_choice  = recode_choice(pre_choice_raw),
    post_choice = recode_choice(post_choice_raw),
    
    pre_scale_real  = to_num(m_2a),
    pre_scale_fake  = to_num(m_2b),
    post_scale_real = to_num(m_4a),
    post_scale_fake = to_num(m_4b),
    
    post_defined = pre_choice %in% c("real","fake"),
    post_by_design_skipped = pre_choice == "wn",
    
    post_choice_routed = case_when(
      post_by_design_skipped ~ "skipped_pre_wn",
      post_defined ~ post_choice,
      TRUE ~ NA_character_
    ),
    post_choice_routed = factor(post_choice_routed, levels = c("real","fake","wn","skipped_pre_wn"))
  )

n_persons_pre <- items %>% summarise(n_persons_pre = n_distinct(id[!is.na(pre_choice)]))

n_persons_prepost <- items %>%
  filter(post_defined, pre_choice %in% c("real","fake"), post_choice %in% c("real","fake")) %>%
  summarise(n_persons_prepost = n_distinct(id))

items_per_person <- seen_tbl %>%
  group_by(id) %>%
  summarise(n_seen = sum(seen_item), .groups = "drop")

items_per_person_desc <- items_per_person %>%
  summarise(n_persons = n(), median = median(n_seen), min = min(n_seen), max = max(n_seen))

# ============================================================
# TEIL C – DESKRIPTIVE OUTPUTS (TABELLEN) mit Routing-Korrektur
# ============================================================

desc_stats <- function(x) {
  x <- x[!is.na(x)]
  tibble(
    n = length(x),
    mean = if (length(x) == 0) NA_real_ else mean(x),
    sd = if (length(x) <= 1) NA_real_ else sd(x),
    median = if (length(x) == 0) NA_real_ else median(x),
    iqr = if (length(x) == 0) NA_real_ else IQR(x),
    min = if (length(x) == 0) NA_real_ else min(x),
    max = if (length(x) == 0) NA_real_ else max(x)
  )
}

prop_within <- function(dat, group_vars, target_var) {
  dat %>%
    count(across(all_of(group_vars)), .data[[target_var]], name = "n") %>%
    group_by(across(all_of(group_vars))) %>%
    mutate(pct = n / sum(n)) %>%
    ungroup()
}

# PRE
pre_choice_total <- items %>%
  count(pre_choice, name = "n") %>%
  mutate(pct = n / sum(n))

pre_choice_by_cell <- prop_within(items, c("cell"), "pre_choice")

pre_choice_missing_by_cond <- items %>%
  mutate(pre_missing = is.na(pre_choice)) %>%
  group_by(source, veracity) %>%
  summarise(n = n(), n_missing = sum(pre_missing), share_missing = mean(pre_missing), .groups = "drop")

n_items_by_cond_pre <- items %>%
  group_by(source, veracity) %>%
  summarise(n = n(), .groups = "drop")

pre_routing_check <- items %>%
  summarise(
    n = n(),
    rate_missing_2a_given_real = mean(pre_choice == "real" & is.na(pre_scale_real), na.rm = TRUE),
    rate_missing_2b_given_fake = mean(pre_choice == "fake" & is.na(pre_scale_fake), na.rm = TRUE)
  )

# POST
post_choice_total <- items %>%
  filter(post_defined) %>%
  count(post_choice, name = "n") %>%
  mutate(pct = n / sum(n))

post_choice_by_cell <- items %>%
  filter(post_defined) %>%
  count(cell, post_choice, name = "n") %>%
  group_by(cell) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup()

n_items_by_cond_post <- items %>%
  filter(post_defined) %>%
  group_by(source, veracity) %>%
  summarise(n = n(), .groups = "drop")

post_routing_check <- items %>%
  filter(post_defined) %>%
  summarise(
    n = n(),
    rate_missing_4a_given_real = mean(post_choice == "real" & is.na(post_scale_real), na.rm = TRUE),
    rate_missing_4b_given_fake = mean(post_choice == "fake" & is.na(post_scale_fake), na.rm = TRUE)
  )

# Transitionen + Wechsel
transition_total_routed <- items %>%
  count(pre_choice, post_choice_routed, name = "n") %>%
  group_by(pre_choice) %>%
  mutate(pct_within_pre = n / sum(n)) %>%
  ungroup()

change_rate_total <- items %>%
  filter(post_defined) %>%
  mutate(changed = !is.na(pre_choice) & !is.na(post_choice) & pre_choice != post_choice) %>%
  summarise(rate_changed = mean(changed, na.rm = TRUE), n = n())

change_direction_total <- items %>%
  filter(post_defined) %>%
  mutate(direction = paste0(pre_choice, "->", post_choice)) %>%
  count(direction, name = "n") %>%
  mutate(pct = n / sum(n))

wn_rates <- items %>%
  summarise(
    pre_wn_rate_all = mean(pre_choice == "wn", na.rm = TRUE),
    post_wn_rate_given_post_defined = mean((post_choice == "wn") & post_defined, na.rm = TRUE),
    share_post_skipped_by_design = mean(post_by_design_skipped, na.rm = TRUE)
  )

pre_wn_by_cond <- items %>%
  group_by(source, veracity) %>%
  summarise(n = n(), share_wn = mean(pre_choice == "wn", na.rm = TRUE), .groups = "drop")

pre_choice_total
pre_choice_by_cell
pre_choice_missing_by_cond
n_items_by_cond_pre
pre_routing_check

post_choice_total
post_choice_by_cell
n_items_by_cond_post
post_routing_check

transition_total_routed
change_rate_total
change_direction_total
wn_rates
pre_wn_by_cond

n_persons_pre
n_persons_prepost
items_per_person_desc

# ============================================================
# >>> NACH TEIL C: KLEINE-KATEGORIEN BEREINIGEN (NUR FÜR MODELLE)
# ============================================================

demo_main_model <- demo_main %>%
  mutate(
    edu_group_model = as.character(edu_group_f),
    edu_group_model = ifelse(edu_group_model == "Anderer", NA_character_, edu_group_model),
    edu_group_model_f = factor(edu_group_model, levels = c("Schule","Beruflich","Akademisch")),
    
    gender_model = as.character(gender_f),
    gender_model = case_when(
      gender_model == "weiblich" ~ "weiblich",
      is.na(gender_model) ~ NA_character_,
      TRUE ~ "nicht_weiblich"
    ),
    gender_model_f = factor(gender_model, levels = c("weiblich","nicht_weiblich"))
  ) %>%
  select(-edu_group_model, -gender_model)

# ============================================================
# TEIL D – item_profile: Pre/Post + Confidence + Routing + Join Demographie
# ============================================================

item_profile <- items %>%
  left_join(demo_main_model, by = "id") %>%
  transmute(
    id, resp_path, path, news, text_id, text_id_32,
    source, veracity, cell,
    pre_choice, post_choice,
    post_defined, post_by_design_skipped, post_choice_routed,
    
    age, age_z,
    gender_f, gender_model_f,
    edu_group_f, edu_group_model_f,
    media_cat, media_hours, media_hours_z,
    
    pre_conf = case_when(
      pre_choice == "real" ~ pre_scale_real,
      pre_choice == "fake" ~ pre_scale_fake,
      TRUE ~ NA_real_
    ),
    
    post_conf = case_when(
      post_defined & post_choice == "real" ~ post_scale_real,
      post_defined & post_choice == "fake" ~ post_scale_fake,
      TRUE ~ NA_real_
    ),
    
    pre_conf_missing_given_choice  = (pre_choice %in% c("real","fake")) & is.na(case_when(
      pre_choice == "real" ~ pre_scale_real,
      pre_choice == "fake" ~ pre_scale_fake
    )),
    
    post_conf_missing_given_choice = post_defined & (post_choice %in% c("real","fake")) & is.na(case_when(
      post_choice == "real" ~ post_scale_real,
      post_choice == "fake" ~ post_scale_fake
    )),
    
    changed = post_defined & !is.na(pre_choice) & !is.na(post_choice) & (pre_choice != post_choice),
    direction = ifelse(post_defined & !is.na(pre_choice) & !is.na(post_choice),
                       paste0(pre_choice, "->", post_choice),
                       NA_character_),
    
    conf_change = ifelse(!is.na(pre_conf) & !is.na(post_conf), post_conf - pre_conf, NA_real_),
    
    conf_change_same_judgment = ifelse(
      post_defined &
        pre_choice %in% c("real","fake") &
        post_choice %in% c("real","fake") &
        pre_choice == post_choice &
        !is.na(pre_conf) & !is.na(post_conf),
      post_conf - pre_conf,
      NA_real_
    )
  )

dup_check <- item_profile %>% count(id, text_id_32) %>% filter(n > 1)
dup_check
