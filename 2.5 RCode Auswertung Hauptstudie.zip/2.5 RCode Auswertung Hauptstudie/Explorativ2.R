# ============================================================
# EXPLORATIV 2 – FAKTOR: PRE-CHOICE
# Ziel:
# Veränderung der Confidence von Pre zu Post
# nach Pre-Choice (real vs. fake) und Status (Switcher vs. Stabil)
# ============================================================

cat("\n==============================\n")
cat("EXPLORATIV: PRE-CHOICE (CONFIDENCE-CHANGE NACH REAL/FAKE UND SWITCH/STABIL)\n")
cat("==============================\n\n")

# ------------------------------------------------------------
# Datensatz für Pre-Choice-Analyse
# ------------------------------------------------------------

conf_prechoice_status <- item_profile %>%
  filter(
    post_defined,
    pre_choice %in% c("real", "fake"),
    post_choice %in% c("real", "fake"),
    !is.na(pre_conf), !is.na(post_conf),
    !is.na(source), !is.na(veracity), !is.na(text_id)
  ) %>%
  left_join(id_w, by = "id") %>%
  mutate(
    status = ifelse(pre_choice != post_choice, "Switcher", "Stabil"),
    status = factor(status, levels = c("Stabil", "Switcher")),
    source_f = factor(source, levels = c("OKI", "KI")),
    veracity_f = factor(veracity, levels = c("Real", "Fake")),
    conf_change = post_conf - pre_conf
  )

# ------------------------------------------------------------
# Gewichtete Auswertung: Pre-Choice × Status
# ------------------------------------------------------------

conf_change_by_prechoice_status_w <- conf_prechoice_status %>%
  group_by(pre_choice, status) %>%
  summarise(
    n = n(),
    n_flag_lt20 = flag_small_n_tbl(n, 20),
    w_sum = sum(w, na.rm = TRUE),
    mean_conf_change = weighted.mean(conf_change, w, na.rm = TRUE),
    w_disp_change = w_dispersion(conf_change, w),
    w_sd_df_change = w_sd_df(conf_change, w),
    .groups = "drop"
  ) %>%
  arrange(pre_choice, status)





# ------------------------------------------------------------
# Ungewichtete Sensitivitätsauswertung: Pre-Choice × Status
# ------------------------------------------------------------

conf_change_by_prechoice_status_nw <- conf_prechoice_status %>%
  group_by(pre_choice, status) %>%
  summarise(
    n = n(),
    n_flag_lt20 = flag_small_n_tbl(n, 20),
    mean_conf_change = mean(conf_change, na.rm = TRUE),
    sd_conf_change = sd(conf_change, na.rm = TRUE),
    median_conf_change = median(conf_change, na.rm = TRUE),
    iqr_conf_change = IQR(conf_change, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(pre_choice, status)

cat("---- Confidence-Change nach Pre-Choice × Status ----\n\n")
cat("Gewichtet:\n")
print(conf_change_by_prechoice_status_w); cat("\n")

cat("Ungewichtet:\n")
print(conf_change_by_prechoice_status_nw); cat("\n")






# ------------------------------------------------------------
# Optional: zusätzlich nach Source
# ------------------------------------------------------------

conf_change_by_prechoice_status_source_w <- conf_prechoice_status %>%
  group_by(source_f, pre_choice, status) %>%
  summarise(
    n = n(),
    n_flag_lt20 = flag_small_n_tbl(n, 20),
    w_sum = sum(w, na.rm = TRUE),
    mean_conf_change = weighted.mean(conf_change, w, na.rm = TRUE),
    w_disp_change = w_dispersion(conf_change, w),
    w_sd_df_change = w_sd_df(conf_change, w),
    .groups = "drop"
  ) %>%
  arrange(source_f, pre_choice, status)

cat("---- Confidence-Change nach Source × Pre-Choice × Status (gewichtet) ----\n\n")
print(conf_change_by_prechoice_status_source_w); cat("\n")
